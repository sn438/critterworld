package simulation;

/** This is a <a href = "https://en.wikipedia.org/wiki/Rock_(geology)">rock</a>. */
public class Rock implements WorldObject
{
	@Override
	public String toString()
	{
		return "#";
	}

	@Override
	public int getAppearance()
	{
		return -1;
	}
}