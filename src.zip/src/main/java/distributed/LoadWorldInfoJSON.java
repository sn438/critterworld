package distributed;

public class LoadWorldInfoJSON {

	private String description;
	
	public LoadWorldInfoJSON(String description) {
		this.description = description;
	}
	
	public String getDescription() {
		return description;
	}
}
