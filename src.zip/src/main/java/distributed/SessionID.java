package distributed;

public class SessionID {

	private int session_id;

	public SessionID(int sessionID) {
		this.session_id = sessionID;
	}
	
	public int getSessionID() {
		return session_id;
	}
}